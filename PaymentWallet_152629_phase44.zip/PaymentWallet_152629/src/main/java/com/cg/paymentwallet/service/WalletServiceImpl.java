package com.cg.paymentwallet.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import javax.persistence.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Transaction;
import com.cg.paymentwallet.repo.ITransactionRepo;
import com.cg.paymentwallet.repo.IWalletRepo;

@Service
public class WalletServiceImpl implements IWalletService {
	@PersistenceContext
	private EntityManager entityManager;
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	
	@Autowired
	IWalletRepo repo;
	@Autowired
	ITransactionRepo trepo;

	@Override
	public void createAccount(Customer customer) {
		repo.save(customer);

	}

	@Override
	public Optional<Customer> showBalance(String mobileno) {

		return repo.findById(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		Optional<Customer> customer1 = repo.findById(sourceMobileNo);
		BigDecimal senderBalance = customer1.get().getWallet().subtract(amount);
		customer1.get().setWallet(senderBalance);
		Customer cust1 = repo.save(customer1.get());

		Optional<Customer> customer2 = repo.findById(targetMobileNo);
		BigDecimal receiverBalance = customer2.get().getWallet().add(amount);
		customer2.get().setWallet(receiverBalance);
		repo.save(customer2.get());

		Transaction transaction = new Transaction();
		transaction.setMobileNo(sourceMobileNo);
		transaction.setMobileNo(targetMobileNo);
		LocalDateTime date = LocalDateTime.now();
		transaction.setTime(date.format(formatter));
		transaction.setTransaction("Amount Transfer :" + amount + "From: " + sourceMobileNo + "to-" + targetMobileNo);
		trepo.save(transaction);

		return cust1;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		Optional<Customer> customer = repo.findById(mobileNo);
		BigDecimal Balance = customer.get().getWallet().add(amount);
		customer.get().setWallet(Balance);
		Customer cust = repo.save(customer.get());

		Transaction transaction = new Transaction();
		transaction.setMobileNo(mobileNo);
		LocalDateTime date = LocalDateTime.now();
		transaction.setTime(date.format(formatter));
		transaction.setTransaction("Amount deposit :" + amount + "From: " + mobileNo);
		trepo.save(transaction);
		return cust;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {

		Optional<Customer> customer = repo.findById(mobileNo);
		BigDecimal Balance = customer.get().getWallet().subtract(amount);
		customer.get().setWallet(Balance);
		Customer cust = repo.save(customer.get());

		Transaction transaction = new Transaction();
		transaction.setMobileNo(mobileNo);
		LocalDateTime date = LocalDateTime.now();
		transaction.setTime(date.format(formatter));
		transaction.setTransaction("Amount Withdraw :" + amount + "From: " + mobileNo);
		trepo.save(transaction);

		return cust;
	}

	@Override
	public List<Transaction> printTransactions(String mobile) {
		Query query = entityManager.createQuery("FROM Transaction where mobile=?");
		query.setParameter(0, mobile);
		List<Transaction> transaction1 = query.getResultList();
		return transaction1;
	}

}
