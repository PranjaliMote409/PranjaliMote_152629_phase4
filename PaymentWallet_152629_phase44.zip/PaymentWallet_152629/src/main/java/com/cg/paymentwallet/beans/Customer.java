package com.cg.paymentwallet.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CustomerDetails")
public class Customer implements Serializable {

	private String name;
	@Id
	private String mobileNo;
	@Embedded
	private Wallet wallet;

	public Customer() {

		wallet = new Wallet();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public BigDecimal getWallet() {
		return wallet.getBalance();
	}

	public void setWallet(BigDecimal amount) {
		wallet.setBalance(amount);
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo + ", wallet=" + wallet + "]";
	}

}
