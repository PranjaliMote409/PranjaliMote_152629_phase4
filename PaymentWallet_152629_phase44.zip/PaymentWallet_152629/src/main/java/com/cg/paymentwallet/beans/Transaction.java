package com.cg.paymentwallet.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Transaction {
	
	private String mobile;
	private String transactions;
	@Id
	private String time;

	public Transaction() {
	}

	public String getMobileNo() {
		return mobile;
	}

	public void setMobileNo(String mobileNo) {
		this.mobile = mobileNo;
	}

	public String getTransaction() {
		return transactions;
	}

	public void setTransaction(String transaction) {
		this.transactions = transaction;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
