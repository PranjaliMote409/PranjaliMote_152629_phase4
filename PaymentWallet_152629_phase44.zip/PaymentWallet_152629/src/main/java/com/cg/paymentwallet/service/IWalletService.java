package com.cg.paymentwallet.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Transaction;

public interface IWalletService {
	
	public void createAccount(Customer customer);

	public Optional<Customer> showBalance(String mobileno);

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount);

	public Customer depositAmount(String mobileNo, BigDecimal amount);

	public Customer withdrawAmount(String mobileNo, BigDecimal amount);

	public List<Transaction> printTransactions(String mobileNo);

	//public boolean validateCreateMethod(String name, String mobileNo) throws InvalidInputException;

	//public boolean validateBalance(BigDecimal balance, String mobileNo) throws InsufficientBalanceException;

	//public boolean validateFundTransfer(BigDecimal balance, String mobileNo) throws InsufficientBalanceException;

	//public boolean checkMobileAvailable(String monbile)throws InvalidInputException;

}
