package com.cg.paymentwallet.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Transaction;

import com.cg.paymentwallet.service.IWalletService;

@RestController
public class WalletController {
	@Autowired
	IWalletService service;

	@RequestMapping("/show/{mobile}")
	public Optional<Customer> showCustomer(@PathVariable String mobile) {
		return service.showBalance(mobile);
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public void addCustomer(@RequestBody Customer customer) {
		service.createAccount(customer);

	}

	@RequestMapping(value = "/withdraw/{mobile}/{amount}", method = RequestMethod.PUT)
	public Customer withdrawAmount(@PathVariable String mobile, @PathVariable BigDecimal amount) {
		return service.withdrawAmount(mobile, amount);

	}

	@RequestMapping(value = "/deposit/{mobile1}/{amount1}", method = RequestMethod.PUT)
	public Customer depositAmount(@PathVariable String mobile1, @PathVariable BigDecimal amount1) {
		return service.depositAmount(mobile1, amount1);
	}

	@RequestMapping(value = "/fundTransfer/{mobile1}/{mobile2}/{amount}", method = RequestMethod.PUT)
	public Customer fundTransfer(@PathVariable String mobile1, @PathVariable String mobile2,
			@PathVariable BigDecimal amount) {
		return service.fundTransfer(mobile1, mobile2, amount);
	}

	@RequestMapping("/transaction/{mobile}")
	public List<Transaction> showTransaction(@PathVariable String mobile) {
		return service.printTransactions(mobile);
	}

}
